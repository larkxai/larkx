import { Metadata } from './common';

export interface JobRole extends Metadata {
  title: string;
  description: string;
}
