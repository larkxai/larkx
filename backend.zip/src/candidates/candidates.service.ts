import { Injectable } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';

export interface Candidate {
  id: string;
  name: string;
  email: string;
  jobId: string;
  status: 'new' | 'in_progress' | 'completed';
  createdAt: string;
  updatedAt: string;
  completedAgents: string[];
  formData: {
    [agentId: string]: {
      timestamp: string;
      values: { [fieldName: string]: string[] };
      chatHistory: Array<{ role: string; content: string }>;
    };
  };
}

@Injectable()
export class CandidatesService {
  private readonly candidates: Candidate[] = [];

  create(data: { name: string; email: string; jobId: string }): Candidate {
    const candidate: Candidate = {
      id: uuidv4(),
      name: data.name,
      email: data.email,
      jobId: data.jobId,
      status: 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      completedAgents: [],
      formData: {},
    };

    this.candidates.push(candidate);
    return candidate;
  }

  findOne(id: string): Candidate | undefined {
    return this.candidates.find((candidate) => candidate.id === id);
  }

  update(id: string, data: Partial<Candidate>): Candidate {
    const candidate = this.findOne(id);
    if (!candidate) {
      throw new Error(`Candidate with ID ${id} not found`);
    }

    Object.assign(candidate, {
      ...data,
      updatedAt: new Date().toISOString(),
    });

    return candidate;
  }

  markAgentComplete(candidateId: string, agentId: string): Candidate {
    const candidate = this.findOne(candidateId);
    if (!candidate) {
      throw new Error(`Candidate with ID ${candidateId} not found`);
    }

    if (!candidate.completedAgents.includes(agentId)) {
      candidate.completedAgents.push(agentId);
      candidate.updatedAt = new Date().toISOString();
    }

    return candidate;
  }

  findAll(): Candidate[] {
    return this.candidates;
  }
}
