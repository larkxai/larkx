import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Put,
  NotFoundException,
} from '@nestjs/common';
import { Candidate, CandidatesService } from './candidates.service';

@Controller('candidates')
export class CandidatesController {
  constructor(private readonly candidatesService: CandidatesService) {}

  @Get()
  findAll() {
    return this.candidatesService.findAll();
  }

  @Post()
  create(@Body() data: { name: string; email: string; jobId: string }) {
    return this.candidatesService.create(data);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    const candidate = this.candidatesService.findOne(id);
    if (!candidate) {
      throw new NotFoundException(`Candidate with ID ${id} not found`);
    }
    return candidate;
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() data: Partial<Candidate>) {
    try {
      return this.candidatesService.update(id, data);
    } catch (error) {
      throw new NotFoundException((error as Error).message);
    }
  }

  @Put(':id/complete-agent/:agentId')
  markAgentComplete(
    @Param('id') id: string,
    @Param('agentId') agentId: string,
  ) {
    try {
      return this.candidatesService.markAgentComplete(id, agentId);
    } catch (error) {
      throw new NotFoundException((error as Error).message);
    }
  }
}
