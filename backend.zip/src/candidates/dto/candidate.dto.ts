export class CandidateDto {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
  location?: string;
  currentRole?: string;
  status:
    | 'new'
    | 'screening'
    | 'interviewing'
    | 'offered'
    | 'hired'
    | 'rejected'
    | 'withdrawn';
  jobId: string;
  jobListingId: string;
  completedAgents: string[];
  currentStage: string;
  formData: {
    [agentId: string]: {
      timestamp: string;
      values: { [fieldName: string]: string };
    };
  };
  isActive: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}
