import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { AgentsModule } from './agents/agents.module';
import { OrganizationsModule } from './organizations/organizations.module';
import { CandidatesModule } from './candidates/candidates.module';
import { JobRolesModule } from './job-roles/job-roles.module';
import { JobListingsModule } from './job-listings/job-listings.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    UsersModule,
    AgentsModule,
    OrganizationsModule,
    CandidatesModule,
    JobRolesModule,
    JobListingsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
