import { Test, TestingModule } from '@nestjs/testing';
import { JobListingsService } from './job-listings.service';

describe('JobListingsService', () => {
  let service: JobListingsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [JobListingsService],
    }).compile();

    service = module.get<JobListingsService>(JobListingsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
