import { AgentFlowDto } from 'src/agents/dto/agent.dto';

export interface JobListingDto {
  id: string;
  title: string;
  description: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract';
  department: string;
  requirements: string[];
  responsibilities: string[];
  salary?: {
    min: number;
    max: number;
    currency: string;
  };
  isActive: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  platform: string;
  agentFlowId: string;
  agentFlow?: AgentFlowDto;
}
