import { Injectable, NotFoundException } from '@nestjs/common';
import { JobListingDto } from './dto/job-listing.dto';

// DEMO DATA
const DEMO_JOB_LISTING: JobListingDto = {
  id: '1',
  title: 'Senior Software Engineer',
  description:
    'We are looking for an experienced software engineer to join our team.',
  location: 'San Francisco, CA',
  type: 'full-time',
  department: 'Engineering',
  requirements: [
    '5+ years of experience in software development',
    'Strong knowledge of TypeScript and Node.js',
    'Experience with cloud platforms (AWS/GCP)',
  ],
  responsibilities: [
    'Design and implement new features',
    'Mentor junior developers',
    'Participate in code reviews',
  ],
  salary: {
    min: 150000,
    max: 200000,
    currency: 'USD',
  },
  isActive: true,
  isDeleted: false,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  platform: 'LinkedIn',
  agentFlowId: 'flow-1',
};

@Injectable()
export class JobListingsService {
  private readonly jobListings: JobListingDto[] = [DEMO_JOB_LISTING];

  findAll(): JobListingDto[] {
    return this.jobListings.filter((listing) => !listing.isDeleted);
  }

  findOne(id: string): JobListingDto {
    const listing = this.jobListings.find((listing) => listing.id === id);
    if (!listing || listing.isDeleted) {
      throw new NotFoundException(`Job listing with ID ${id} not found`);
    }
    return listing;
  }

  create(data: Partial<JobListingDto>): JobListingDto {
    const newJob: JobListingDto = {
      ...data,
      id: Date.now().toString(),
      isActive: true,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      platform: data.platform || 'website',
      agentFlowId: data.agentFlowId || '',
    } as JobListingDto;
    this.jobListings.push(newJob);
    return newJob;
  }
}
