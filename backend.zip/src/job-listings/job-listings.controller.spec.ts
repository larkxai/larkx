import { Test, TestingModule } from '@nestjs/testing';
import { JobListingsController } from './job-listings.controller';

describe('JobListingsController', () => {
  let controller: JobListingsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [JobListingsController],
    }).compile();

    controller = module.get<JobListingsController>(JobListingsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
