import { Controller, Get, Param, Post, Body } from '@nestjs/common';
import { JobListingsService } from './job-listings.service';
import { JobListingDto } from './dto/job-listing.dto';

@Controller('jobs/listings')
export class JobListingsController {
  constructor(private readonly jobListingsService: JobListingsService) {}

  @Get()
  findAll(): JobListingDto[] {
    return this.jobListingsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): JobListingDto {
    return this.jobListingsService.findOne(id);
  }

  @Post()
  create(@Body() data: Partial<JobListingDto>): JobListingDto {
    return this.jobListingsService.create(data);
  }
}
