export class UserDto {
  id: string;
  email: string;
  name: string;
  role: string;
  lastLoginAt: string;
  isActive: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
}
