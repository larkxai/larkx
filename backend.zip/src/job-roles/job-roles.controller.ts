import { Controller } from '@nestjs/common';

@Controller('job-roles')
export class JobRolesController {}
