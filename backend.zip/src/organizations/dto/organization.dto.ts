export interface TeamDto {
  id: string;
  name: string;
  logoUrl?: string;
}

export interface OrganizationDto {
  id: string;
  name: string;
  teams: TeamDto[];
  currentPlan: {
    name: string;
    features: string[];
  };
  createdAt: string;
  updatedAt: string;
}
