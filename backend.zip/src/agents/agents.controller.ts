import {
  Controller,
  Get,
  Param,
  Post,
  Body,
  NotFoundException,
  Put,
} from '@nestjs/common';
import { AgentsService } from './agents.service';
import { AgentDto, AgentFlowDto, AgentType } from './dto/agent.dto';
import { FormAgentService } from './form-agent.service';

@Controller('agents')
export class AgentsController {
  constructor(
    private readonly agentsService: AgentsService,
    private readonly formAgentService: FormAgentService,
  ) {}

  @Get('flows')
  findAllFlows(): AgentFlowDto[] {
    return this.agentsService.findAllFlows();
  }

  @Get('flows/:id')
  findFlowById(@Param('id') id: string): AgentFlowDto {
    return this.agentsService.findFlowById(id);
  }

  @Get('flows/:flowId/agents/:agentId')
  findAgentById(
    @Param('flowId') flowId: string,
    @Param('agentId') agentId: string,
  ): AgentDto {
    return this.agentsService.findAgentById(flowId, agentId);
  }

  @Post('flows')
  createFlow(
    @Body()
    flowData: {
      name: string;
      description: string;
      isTemplate: boolean;
    },
  ): AgentFlowDto {
    return this.agentsService.createFlow(flowData);
  }

  @Post('trigger')
  async triggerAgent(
    @Body()
    body: {
      candidateId: string;
      flowId: string;
      agentId: string;
      message?: string;
      history?: any[];
    },
  ) {
    const { candidateId, flowId, agentId, message, history } = body;

    // Get the agent from the flow
    const agent = this.agentsService.findAgentById(flowId, agentId);
    if (!agent) {
      throw new NotFoundException(`Agent ${agentId} not found`);
    }

    // Handle different agent types
    switch (agent.type) {
      case AgentType.FormAgent:
        return this.formAgentService.handleFormAgent(
          agent,
          candidateId,
          message,
          history,
        );
      default:
        throw new Error(`Unsupported agent type: ${agent.type}`);
    }
  }

  @Put('flows/:id')
  updateFlow(
    @Param('id') id: string,
    @Body() flowData: AgentFlowDto
  ): AgentFlowDto {
    return this.agentsService.updateFlow(id, flowData);
  }
}
