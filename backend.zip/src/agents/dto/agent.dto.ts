export enum AgentMode {
  Linear = 'Linear',
  Passive = 'Passive',
}

export enum AgentType {
  FormAgent = 'FormAgent',
  ReminderAgent = 'ReminderAgent',
}

interface FormField {
  name: string;
  label: string;
  type: 'text' | 'email' | 'number' | 'url';
  required: boolean;
}

export interface FormAgentConfig {
  fields: FormField[];
}

interface ReminderAgentConfig {
  message: string;
  delay: string;
}

export class AgentDto {
  id: string;
  flowId: string;
  type: AgentType;
  name: string;
  mode: AgentMode;
  after: string | null;
  config: FormAgentConfig | ReminderAgentConfig;
}

export class AgentFlowDto {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  isTemplate: boolean;
  version: number;
  createdAt: Date;
  agents: AgentDto[];
};