import { Injectable, NotFoundException } from '@nestjs/common';
import { AgentDto, AgentFlowDto, AgentMode, AgentType } from './dto/agent.dto';

const DEMO_AGENT_FLOWS: AgentFlowDto[] = [
  {
    id: 'flow-1',
    name: 'Software Engineer Flow',
    description: 'Standard flow for software engineering positions',
    createdBy: 'system',
    isTemplate: true,
    version: 1,
    createdAt: new Date('2024-03-15'),
    agents: [
      {
        id: 'agent1',
        flowId: 'flow-1',
        type: AgentType.FormAgent,
        name: 'Agent 1',
        mode: AgentMode.Linear,
        after: null,
        config: {
          fields: [
            {
              name: 'fullName',
              label: 'Full Name',
              type: 'text',
              required: true,
            },
            { name: 'email', label: 'Email', type: 'email', required: true },
            {
              name: 'experience',
              label: 'Years of Experience',
              type: 'number',
              required: true,
            },
          ],
        },
      },
      {
        id: 'agent2',
        flowId: 'flow-1',
        type: AgentType.ReminderAgent,
        name: 'Agent 2',
        mode: AgentMode.Passive,
        after: 'agent1',
        config: {
          message: 'Please complete your application',
          delay: '24h',
        },
      },
    ],
  },
  {
    id: 'flow2',
    name: 'Product Manager Flow',
    description: 'Standard flow for product management positions',
    createdBy: 'system',
    isTemplate: true,
    version: 1,
    createdAt: new Date('2024-03-15'),
    agents: [
      {
        id: 'agent3',
        flowId: 'flow2',
        type: AgentType.FormAgent,
        name: 'Agent 1',
        mode: AgentMode.Linear,
        after: null,
        config: {
          fields: [
            {
              name: 'fullName',
              label: 'Full Name',
              type: 'text',
              required: true,
            },
            { name: 'email', label: 'Email', type: 'email', required: true },
            {
              name: 'portfolio',
              label: 'Portfolio URL',
              type: 'url',
              required: true,
            },
          ],
        },
      },
    ],
  },
];

@Injectable()
export class AgentsService {
  private readonly agentFlows: AgentFlowDto[] = DEMO_AGENT_FLOWS;

  findAllFlows(): AgentFlowDto[] {
    return this.agentFlows;
  }

  findFlowById(id: string): AgentFlowDto {
    const flow = this.agentFlows.find((flow) => flow.id === id);
    if (!flow) {
      throw new NotFoundException(`Flow with id ${id} not found`);
    }
    return flow;
  }

  findAgentById(flowId: string, agentId: string): AgentDto {
    const flow = this.findFlowById(flowId);
    const agent = flow.agents.find((agent) => agent.id === agentId);
    if (!agent) {
      throw new NotFoundException(
        `Agent with id ${agentId} not found in flow ${flowId}`,
      );
    }
    return agent;
  }

  createFlow(data: {
    name: string;
    description: string;
    isTemplate: boolean;
  }): AgentFlowDto {
    const newFlow: AgentFlowDto = {
      id: `flow-${Date.now()}`,
      name: data.name,
      description: data.description,
      createdBy: 'system',
      isTemplate: data.isTemplate,
      version: 1,
      createdAt: new Date(),
      agents: [],
    };
    this.agentFlows.push(newFlow);
    return newFlow;
  }

  updateFlow(id: string, flowData: AgentFlowDto): AgentFlowDto {
    const index = this.agentFlows.findIndex((flow) => flow.id === id);
    if (index === -1) {
      throw new NotFoundException(`Flow with id ${id} not found`);
    }
    this.agentFlows[index] = { ...flowData, id };
    return this.agentFlows[index];
  }
}
