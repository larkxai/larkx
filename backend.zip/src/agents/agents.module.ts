import { Module } from '@nestjs/common';
import { AgentsController } from './agents.controller';
import { AgentsService } from './agents.service';
import { FormAgentService } from './form-agent.service';
import { OpenAIModule } from '../openai/openai.module';
import { CandidatesModule } from '../candidates/candidates.module';

@Module({
  imports: [OpenAIModule, CandidatesModule],
  controllers: [AgentsController],
  providers: [AgentsService, FormAgentService],
})
export class AgentsModule {}
