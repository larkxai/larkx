/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { Injectable } from '@nestjs/common';
import { AgentDto, AgentType } from './dto/agent.dto';
import { OpenAIService } from '../openai/openai.service';
import { CandidatesService } from '../candidates/candidates.service';
import { FormAgentConfig } from './dto/agent.dto';

@Injectable()
export class FormAgentService {
  constructor(
    private readonly openAIService: OpenAIService,
    private readonly candidatesService: CandidatesService,
  ) {}

  async handleFormAgent(
    agent: AgentDto,
    candidateId: string,
    message?: string,
    history?: any[],
  ): Promise<{ response: string; isComplete: boolean }> {
    if (agent.type !== AgentType.FormAgent) {
      throw new Error('Invalid agent type');
    }

    const candidate = this.candidatesService.findOne(candidateId);
    const formData = candidate?.formData?.[agent.id] || {};
    const fields = (agent.config as FormAgentConfig).fields;
    const chatHistory = history || [];

    // If no message provided, this is the initial trigger
    if (!message) {
      const nextField = this.getNextUnansweredField(fields, formData);
      if (!nextField) {
        return {
          response:
            'Thank you! You have completed all the required information.',
          isComplete: true,
        };
      }

      const prompt = await this.generateFieldPrompt(nextField);
      // Save the system prompt to chat history
      this.candidatesService.update(candidateId, {
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: candidate?.formData?.[agent.id]?.values || {},
            chatHistory: [
              ...(candidate?.formData?.[agent.id]?.chatHistory || []),
              { role: 'system', content: prompt },
            ],
          },
        },
      });
      return {
        response: prompt,
        isComplete: false,
      };
    }

    // Always add the new message to chat history, even if invalid
    chatHistory.push({ role: 'user', content: message });

    // Use LLM for field detection and validation
    const llmPrompt = `You are a helpful assistant guiding a user through a form. Here are the required fields:\n${fields.map((f) => `- ${f.name} (${f.type}): ${f.label}`).join('\n')}\n\nCurrent form data:\n${JSON.stringify(candidate?.formData?.[agent.id]?.values || {}, null, 2)}\n\nUser message:\n"${message}"\n\nInstructions:\n- If the message is a valid answer for a field, respond with:\n  { "fieldName": "...", "isValid": true, "reason": "...", "value": "..." }\n- If the message is a question or unrelated, respond with:\n  { "fieldName": null, "isValid": false, "reason": "User asked a question", "reply": "..." }\n- If the message is an invalid answer for a field, respond with:\n  { "fieldName": "...", "isValid": false, "reason": "Why it's invalid", "reply": "..." }`;

    const llmResponseRaw = await this.openAIService.generateText(llmPrompt);
    let llmResponse: any;
    try {
      llmResponse = JSON.parse(llmResponseRaw);
    } catch {
      // Fallback: ask for clarification
      const clarification =
        "I'm not sure which information you're providing. Could you please clarify?";
      this.candidatesService.update(candidateId, {
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: candidate?.formData?.[agent.id]?.values || {},
            chatHistory: [
              ...(candidate?.formData?.[agent.id]?.chatHistory || []),
              { role: 'user', content: message },
              { role: 'system', content: clarification },
            ],
          },
        },
      });
      return {
        response: clarification,
        isComplete: false,
      };
    }

    // Handle LLM response
    if (llmResponse.isValid && llmResponse.fieldName) {
      // Valid answer for a field
      const updatedValues = {
        ...(candidate?.formData?.[agent.id]?.values || {}),
        [llmResponse.fieldName]: [llmResponse.value],
      };
      const updatedChatHistory = [
        ...(candidate?.formData?.[agent.id]?.chatHistory || []),
        { role: 'user', content: message },
        { role: 'system', content: llmResponse.reason },
      ];
      this.candidatesService.update(candidateId, {
        completedAgents: [...(candidate?.completedAgents || []), agent.id],
        status: 'in_progress',
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: updatedValues,
            chatHistory: updatedChatHistory,
          },
        },
      });
      // Use updatedValues for the next field check and prompt
      const nextField = this.getNextUnansweredField(fields, updatedValues);
      if (!nextField) {
        const isComplete = await this.evaluateCompletion(
          fields,
          updatedValues,
          updatedChatHistory,
        );
        return {
          response: isComplete
            ? 'Thank you! You have completed all the required information.'
            : 'Please provide more information.',
          isComplete,
        };
      }
      const prompt = await this.generateFieldPrompt(nextField);
      // Add the next prompt to chat history as well
      this.candidatesService.update(candidateId, {
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: updatedValues,
            chatHistory: [
              ...updatedChatHistory,
              { role: 'system', content: prompt },
            ],
          },
        },
      });
      return {
        response: prompt,
        isComplete: false,
      };
    } else if (!llmResponse.isValid && llmResponse.fieldName) {
      // Invalid answer for a field
      const updatedChatHistory = [
        ...(candidate?.formData?.[agent.id]?.chatHistory || []),
        { role: 'user', content: message },
        { role: 'system', content: llmResponse.reply || llmResponse.reason },
      ];
      this.candidatesService.update(candidateId, {
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: candidate?.formData?.[agent.id]?.values || {},
            chatHistory: updatedChatHistory,
          },
        },
      });
      return {
        response: llmResponse.reply || llmResponse.reason,
        isComplete: false,
      };
    } else if (!llmResponse.isValid && !llmResponse.fieldName) {
      // User asked a question or unrelated
      const updatedChatHistory = [
        ...(candidate?.formData?.[agent.id]?.chatHistory || []),
        { role: 'user', content: message },
        { role: 'system', content: llmResponse.reply || llmResponse.reason },
      ];
      this.candidatesService.update(candidateId, {
        formData: {
          ...(candidate?.formData || {}),
          [agent.id]: {
            timestamp: new Date().toISOString(),
            values: candidate?.formData?.[agent.id]?.values || {},
            chatHistory: updatedChatHistory,
          },
        },
      });
      return {
        response: llmResponse.reply || llmResponse.reason,
        isComplete: false,
      };
    }
    // Fallback: ask for clarification
    const clarification =
      "I'm not sure which information you're providing. Could you please clarify?";
    this.candidatesService.update(candidateId, {
      formData: {
        ...(candidate?.formData || {}),
        [agent.id]: {
          timestamp: new Date().toISOString(),
          values: candidate?.formData?.[agent.id]?.values || {},
          chatHistory: [
            ...(candidate?.formData?.[agent.id]?.chatHistory || []),
            { role: 'user', content: message },
            { role: 'system', content: clarification },
          ],
        },
      },
    });
    return {
      response: clarification,
      isComplete: false,
    };
  }

  private getNextUnansweredField(
    fields: FormAgentConfig['fields'],
    formData: Record<string, string[]>,
  ) {
    // Check each field in order from the form configuration
    for (const field of fields) {
      // If the field is required and has no value, or if it's optional and empty
      if (
        field.required &&
        (!formData[field.name] || formData[field.name].length === 0)
      ) {
        return field;
      }
    }
    return null;
  }

  private getCurrentField(
    fields: FormAgentConfig['fields'],
    formData: Record<string, string[]>,
  ) {
    // Check each field in order from the form configuration
    for (const field of fields) {
      if (!formData[field.name]?.length) {
        return field;
      }
    }
    return null;
  }

  private validateFieldResponse(
    field: FormAgentConfig['fields'][0],
    value: string,
  ): { isValid: boolean; error?: string } {
    if (!value.trim()) {
      return { isValid: false, error: 'This field is required.' };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    switch (field.type) {
      case 'email':
        if (!emailRegex.test(value)) {
          return {
            isValid: false,
            error: 'Please enter a valid email address.',
          };
        }
        break;
      case 'number':
        if (isNaN(Number(value))) {
          return { isValid: false, error: 'Please enter a valid number.' };
        }
        break;
      case 'url':
        try {
          new URL(value);
        } catch {
          return { isValid: false, error: 'Please enter a valid URL.' };
        }
        break;
      case 'text':
        // Prevent emails and URLs from being accepted as names
        try {
          new URL(value);
          return {
            isValid: false,
            error: 'Please enter a valid name, not a URL.',
          };
        } catch {}
        if (emailRegex.test(value)) {
          return {
            isValid: false,
            error: 'Please enter a valid name, not an email.',
          };
        }
        break;
    }

    return { isValid: true };
  }

  private async generateFieldPrompt(
    field: FormAgentConfig['fields'][0],
  ): Promise<string> {
    const prompt = `Generate a friendly, conversational question to ask for the following form field:
    Field Name: ${field.name}
    Field Label: ${field.label}
    Field Type: ${field.type}
    Required: ${field.required}

    The question should be natural and engaging, as if asking a friend.`;

    const response = await this.openAIService.generateText(prompt);
    return response.trim();
  }

  private async evaluateCompletion(
    fields: FormAgentConfig['fields'],
    formData: Record<string, string[]>,
    chatHistory: any[],
  ): Promise<boolean> {
    const prompt = `Evaluate if all required information has been provided based on the following:

    Required Fields:
    ${fields.map((f) => `- ${f.name} (${f.type}): ${f.required ? 'Required' : 'Optional'}`).join('\n')}

    Current Form Data:
    ${JSON.stringify(formData, null, 2)}

    Chat History:
    ${JSON.stringify(chatHistory, null, 2)}

    Please analyze if all required fields have been properly filled out. Consider the chat history for context.
    Respond with a JSON object: { "isComplete": boolean, "reason": string }`;

    const response = await this.openAIService.generateText(prompt);
    try {
      const result = JSON.parse(response);
      return result.isComplete;
    } catch {
      // If parsing fails, default to checking if all required fields have values
      return fields.every(
        (field) =>
          !field.required ||
          (formData[field.name] && formData[field.name].length > 0),
      );
    }
  }

  private async determineFieldForResponse(
    fields: FormAgentConfig['fields'],
    message: string,
    chatHistory: any[],
    currentField?: FormAgentConfig['fields'][0],
  ): Promise<FormAgentConfig['fields'][0] | null> {
    const prompt = `You are a form field analyzer. Your task is to determine which form field the user's response belongs to.

    Available Fields:
    ${fields.map((f) => `- ${f.name} (${f.type}): ${f.label}`).join('\n')}

    Message: ${message}

    Chat History:
    ${JSON.stringify(chatHistory, null, 2)}

    Rules:
    1. If the message contains an email address, it belongs to the email field
    2. If the message contains a name or full name, it belongs to the fullName field
    3. If the message contains a number, it belongs to the number field
    4. If the message contains a URL, it belongs to the url field
    5. For text fields (like fullName), if the message is a non-empty string and the current question is about that field, accept it
    6. Consider the context from chat history
    7. Only return a field if you are highly confident
    8. If a field already has a value in the chat history, do not return it again

    Respond with a JSON object: { "fieldName": string, "confidence": number, "reason": string }
    The fieldName should match one of the available fields above.`;

    const response = await this.openAIService.generateText(prompt);
    try {
      const result = JSON.parse(response);
      if (result.confidence > 0.8) {
        // Check if this field already has a value in the chat history
        const field = fields.find((f) => f.name === result.fieldName);
        if (field) {
          // Look for previous values of this field in chat history
          const hasPreviousValue = chatHistory.some((entry) => {
            if (entry.role === 'user') {
              switch (field.type) {
                case 'email':
                  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(entry.content);
                case 'number':
                  return !isNaN(Number(entry.content));
                case 'url':
                  try {
                    new URL(entry.content);
                    return true;
                  } catch {
                    return false;
                  }
                default:
                  return entry.content.length > 0;
              }
            }
            return false;
          });

          if (hasPreviousValue) {
            return null; // Skip this field if it already has a value
          }
        }
        return field || null;
      }
    } catch {
      // If parsing fails, return null
    }
    // Fallback: if the current field is a required text field and the message is non-empty, accept it
    if (
      currentField &&
      currentField.type === 'text' &&
      currentField.required &&
      typeof message === 'string' &&
      message.trim().length > 0
    ) {
      return currentField;
    }
    return null;
  }
}
